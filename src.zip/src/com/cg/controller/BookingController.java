package com.cg.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.bean.Hotel;
import com.cg.bean.HotelBooking;
import com.cg.service.IBookingService;

@Controller
public class BookingController {
	@Autowired
	private IBookingService hService;

	@RequestMapping("/index")
	public String showHotelDetails(Model model) {
		System.out.println("Show All Hotels");
		List<Hotel> hList = hService.getHotelDetails();
		model.addAttribute("hlist", hList);
		return "hotelDetails";
	}

	@RequestMapping("bookHotel")
	public String bookHotel(@RequestParam("hid") String hId,
			@RequestParam("hname") String hName, Model model) {
		model.addAttribute("hname", hName);
		model.addAttribute("hid", Integer.valueOf(hId));
		model.addAttribute("hotelroom", new HotelBooking());
		return "hbookingform";
	}

	@RequestMapping("bookRoom")
	public String bookRoom(@RequestParam("hname") String hName,
			@RequestParam("hid") String hId,
			@ModelAttribute("hotelroom")@Valid HotelBooking room,
			BindingResult bindingResult, Model model) {
		System.out.println("Submitting Product...Validating...");
		boolean hasError = bindingResult.hasErrors();
		if (!hasError) {
			room.setHotelId(Integer.valueOf(hId));
			double rate = hService.getRoomRate(room.getHotelId());
			hService.addRoom(room);
			System.out.println(room);
			double amount = rate * room.getNoOfRooms();
			model.addAttribute("amount", amount);
			model.addAttribute("bookedroom", room);
			model.addAttribute("hname", hName);
			return "bookingConfirmation";

		} else {
			System.out.println("Room not Booked");
			model.addAttribute("hid", Integer.valueOf(hId));
			model.addAttribute("hname", hName);
			return "hbookingform";
		}
	}

	@ExceptionHandler(Exception.class)
	public ModelAndView handleError(Exception e) {
		ModelAndView mav = new ModelAndView();
		mav.addObject("err", e);
		mav.setViewName("dataError");
		return mav;
	}

}
