package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.bean.Hotel;
import com.cg.bean.HotelBooking;

@Transactional
@Repository
public class BookingDaoImpl implements IBookingDao{

	@PersistenceContext
	private EntityManager eManager;

	
	@Override
	public List<Hotel> getHotelDetails() {
		String sql = "Select h from Hotel h";
		TypedQuery<Hotel> query = eManager.createQuery(sql,Hotel.class);
		List<Hotel> hList = query.getResultList();
		System.out.println("I'm Here");
		System.out.println(hList);
		return hList;
	}


	@Override
	public boolean addRoom(HotelBooking room) {
		boolean success = false;
		try {
			eManager.persist(room);
			success = true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return success;
	}

	@Override
	public double getRoomRate(int hotelId) {
		String sql = "Select h.rate from Hotel h where h.id=" + hotelId;
		TypedQuery<Double> query = eManager.createQuery(sql,Double.class);
		double res = query.getSingleResult();
		return res;
	}

	
	
}
