package com.cg.dao;

import java.util.List;

import com.cg.bean.Hotel;
import com.cg.bean.HotelBooking;

public interface IBookingDao {

	public List<Hotel> getHotelDetails();

	public boolean addRoom(HotelBooking room);

	public double getRoomRate(int hotelId);

}
