package com.cg.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bean.Hotel;
import com.cg.bean.HotelBooking;
import com.cg.dao.IBookingDao;

@Transactional
@Service
public class BookingServiceImpl implements IBookingService {
	@Autowired
	private IBookingDao hDao;

	@Override
	public List<Hotel> getHotelDetails() {
		// TODO Auto-generated method stub
		return hDao.getHotelDetails();
	}

	@Override
	public boolean addRoom(HotelBooking room) {
		return hDao.addRoom(room);
	}

	@Override
	public double getRoomRate(int hotelId) {
		// TODO Auto-generated method stub
		return hDao.getRoomRate(hotelId);
	}

}
