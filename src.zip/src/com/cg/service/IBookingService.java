package com.cg.service;

import java.util.List;

import com.cg.bean.Hotel;
import com.cg.bean.HotelBooking;

public interface IBookingService {

	public List<Hotel> getHotelDetails();

	public boolean addRoom(HotelBooking room);

	public double getRoomRate(int hotelId);

}
